import { z, _ } from "../chunks/2.y7UIYSlv.js";
export {
  z as component,
  _ as universal
};
